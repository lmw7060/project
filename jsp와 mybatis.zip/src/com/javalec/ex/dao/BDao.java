package com.javalec.ex.dao;
import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.ex.dto.BDto;
public interface BDao<T, K> {
	public void write(BDto vo);
	public ArrayList<BDto> list();
	public BDto contentView(int bId);
	public void modify(BDto vo);
	public void delete(int bId);
	public BDto reply_view(int bId);
	public void reply(BDto vo);
	public void replyShape(HashMap<String,Integer> map);
	public void upHit( int bId);
}
