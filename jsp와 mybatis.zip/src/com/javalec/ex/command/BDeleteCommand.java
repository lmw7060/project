package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.javalec.ex.dao.BDao;
import com.sjw.common.MBUtils;

public class BDeleteCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		int bId = Integer.parseInt(request.getParameter("bId"));
		SqlSession session = MBUtils.getSession(); 
		BDao dao = session.getMapper(BDao.class);
		dao.delete(bId);
		
	}

}
