package com.javalec.ex.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.javalec.ex.dao.BDao;
import com.javalec.ex.dto.BDto;
import com.sjw.common.MBUtils;

public class BListCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		SqlSession session = MBUtils.getSession(); 
		BDao dao = session.getMapper(BDao.class);
		ArrayList<BDto> dtos = dao.list();
		// 리퀘스트 정보에 객체를 지정하고 있다.
		request.setAttribute("list", dtos);
	}
}