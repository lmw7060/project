package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.javalec.ex.dao.BDao;
import com.javalec.ex.dto.BDto;
import com.sjw.common.MBUtils;

public class BWriteCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		String bName = request.getParameter("bName");
		String bTitle = request.getParameter("bTitle");
		String bContent = request.getParameter("bContent");
		
		SqlSession session = MBUtils.getSession(); 
		BDao dao = session.getMapper(BDao.class);
		BDto vo = new BDto();
		vo.setbName(bName);
		vo.setbTitle(bTitle);
		vo.setbContent(bContent);
		dao.write(vo);
	}
}
