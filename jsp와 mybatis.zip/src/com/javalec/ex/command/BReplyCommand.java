package com.javalec.ex.command;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.javalec.ex.dao.BDao;
import com.javalec.ex.dto.BDto;
import com.sjw.common.MBUtils;

public class BReplyCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub

		//int bId = Integer.parseInt(request.getParameter("bId"));//-------------------------------
		String bName = request.getParameter("bName");
		String bTitle = request.getParameter("bTitle");
		String bContent = request.getParameter("bContent");
		int bGroup = Integer.parseInt(request.getParameter("bGroup"));
		int bStep = Integer.parseInt(request.getParameter("bStep"));
		int bIndent = Integer.parseInt(request.getParameter("bIndent"));
		
		SqlSession session = MBUtils.getSession(); 
		BDao dao = session.getMapper(BDao.class);
		// 중요한 과정 - 댓글의 순서 조정 
		HashMap<String,Integer> map = new HashMap<>(); 
		map.put("bGroup", new Integer(bGroup));
		map.put("bStep", new Integer(bStep));
		dao.replyShape(map);//-------------------------------------
		// 댓글관련 정보를 vo객체로 만들어
		BDto vo = new BDto();
		//vo.setbId(bId);//---------------------------------
		vo.setbName(bName);vo.setbTitle(bTitle);
		vo.setbContent(bContent);vo.setbGroup(bGroup);vo.setbStep(bStep);
		vo.setbIndent(bIndent);
		// 디비에 넣는다.
		dao.reply(vo);
	}

}
