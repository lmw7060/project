package com.java.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.java.board.dto.BDto;

public class BDao implements IDao{

	@Autowired
	JdbcTemplate template;
	public int bGroup;
	public int bStep;

	public BDao() {	
	}

	@Override
	public BDto content_view(int bId) {
		System.out.println("content_view");
		String query = "select * from mvc_board where bId = " + bId;
		return template.queryForObject(query, new BeanPropertyRowMapper<BDto>(BDto.class));
	}

	@Override
	public void write(final String bName, final String bTitle, final String bContent) {
		System.out.println("write()");
		this.template.update(new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				String query = "insert into mvc_board (bId, bName, bTitle, bContent, bHit, bGroup, bStep, bIndent) "
						+ "values (mvc_board_seq.nextval, ?, ?, ?, 0, mvc_board_seq.currval, 0, 0)";
				PreparedStatement pstmt =con.prepareStatement(query);
				pstmt.setString(1, bName);
				pstmt.setString(2, bTitle);
				pstmt.setString(3, bContent);
				return pstmt;
			}
		});
		
	}

	@Override
	public ArrayList<BDto> list() {
		String query = "select bId, bName, bTitle, bContent, bDate, bHit, bGroup, bStep, bIndent "
				+ "from mvc_board order by bGroup desc, bStep asc";
		ArrayList<BDto> dtos = (ArrayList<BDto>) template.query(query,new BeanPropertyRowMapper<BDto>(BDto.class));
		return dtos;
	}

	@Override
	public void modify(final String bName, final String bTitle, final String bContent, final String bId) {
		System.out.println("modify()");
		String query = "update mvc_board set bName = ?, bTitle = ?, bContent = ? where bId = ?";
		this.template.update(query,new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, bName);
				ps.setString(2, bTitle);
				ps.setString(3, bContent);				
				ps.setInt(4, Integer.parseInt(bId));
			}
		});
	}

	@Override
	public void delete(final String bId) {
		System.out.println("delete()");
		String query = "delete from mvc_board where bId = " + bId;
		this.template.update(query,new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, bId);
			}
		});
		
	}

	@Override
	public BDto reply_view(int bId) {
		String query = "select * from mvc_board where bId = " + bId;
		return template.queryForObject(query,new BeanPropertyRowMapper<BDto>(BDto.class));
	}

	@Override
	public void reply(final String bName, final String bTitle, final String bContent, final String bGroup, final String bStep,
			final String bIndent) {
		
		System.out.println("reply()");
		String query = "insert into mvc_board (bId, bName, bTitle, bContent, bGroup, bStep, bIndent) "
			     + "values (mvc_board_seq.nextval, ?, ?, ?, ? ,? ,?)";
		this.template.update(query,new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				// TODO Auto-generated method stub
				ps.setString(1, bName);
				ps.setString(2, bTitle);
				ps.setString(3, bContent);
				ps.setInt(4, Integer.parseInt(bGroup));// 본글과 그룹은 같게
				ps.setInt(5, Integer.parseInt(bStep) + 1);// 스텝 추가
				ps.setInt(6, Integer.parseInt(bIndent) + 1);// 들여쓰기 추가
			}
			});
		
	}

	@Override
	public void upHit(final int bId) {
		System.out.println("upHit()");
		String query = "update mvc_board set bHit = bHit + 1 where bId = ?";
		this.template.update(query,new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, bId);
			}
		});
		
	}
	@Override
	public void replyShape(HashMap<Integer,Integer> map) {

		String query = "update mvc_board set bStep = bStep + 1 where bGroup = ? and bStep > ?";
		template.update(query, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, bGroup);
				ps.setInt(2, bStep);
	
			}
			});
}
	
}