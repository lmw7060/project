package com.java.board;

import java.text.DateFormat;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.java.board.dto.*;
import com.java.board.dao.IDao;
import com.java.service.BListService;
import com.java.service.Constant;
import com.java.service.IBoarderService;

@Controller
public class HomeController {
	IBoarderService service;
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	@Autowired
	private SqlSession sqlSession;
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
		Constant.sqlSession=this.sqlSession;
	}
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	@RequestMapping("/list")
	public String list(HttpServletRequest request,Model model) {
		IDao dao=sqlSession.getMapper(IDao.class);
		model.addAttribute("list",dao.list());
		return "/list";
	}
	
	@RequestMapping("/write_view")
	public String write_view(HttpServletRequest request,Model model) {
		System.out.println("write_view()");
		return "/write_view";
	}
	
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request,Model model) {
		IDao dao =sqlSession.getMapper(IDao.class);
		int bId = Integer.parseInt(request.getParameter("bId"));
		dao.upHit(bId);
		dao.content_view(bId);
		model.addAttribute("content_view",dao.content_view(bId));
		System.out.println("content_view()");
		return "/content_view";
	}
	
	@RequestMapping("/reply_view")
	public String reply_view(HttpServletRequest request,Model model) {
		IDao dao =sqlSession.getMapper(IDao.class);
		int bId = Integer.parseInt(request.getParameter("bId"));
		dao.reply_view(bId);
		model.addAttribute("reply_view",dao.reply_view(bId));
		System.out.println("reply_view()");
		return "/reply_view";
	}
	
	@RequestMapping("/write")
	public String write(HttpServletRequest request, Model model) {
		IDao dao =sqlSession.getMapper(IDao.class);
		dao.write(request.getParameter("bName"), request.getParameter("bTitle"), request.getParameter("bContent"));
		System.out.println("write()");
		return "redirect:list";
	}	
	
	@RequestMapping("/modify")
	public String modify(HttpServletRequest request, Model model) {
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.modify(request.getParameter("bName"),request.getParameter("bTitle"),
				request.getParameter("bContent"),request.getParameter("bId"));
		System.out.println("modify()");
		return "redirect:list";
	}
		
	@RequestMapping("/reply")
	public String reply(HttpServletRequest request, Model model) {
		IDao dao =sqlSession.getMapper(IDao.class);
		int bGroup = Integer.parseInt(request.getParameter("bGroup"));
		int bStep = Integer.parseInt(request.getParameter("bStep"));
		HashMap<Integer,Integer> map =new HashMap<Integer,Integer>();
		map.put(bGroup, new Integer(bGroup));
		map.put(bStep, new Integer(bStep));
		dao.replyShape(map);
		dao.reply(request.getParameter("bName"),request.getParameter("bTitle"),
				request.getParameter("bContent"),request.getParameter("bGroup"),
				request.getParameter("bStep"),request.getParameter("bIndent"));
		System.out.println("reply()");
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		IDao dao =sqlSession.getMapper(IDao.class);
		dao.delete(request.getParameter("bId"));
		System.out.println("delete()");
		return "redirect:list";
	}
}
