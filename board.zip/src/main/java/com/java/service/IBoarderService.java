package com.java.service;

import org.springframework.ui.Model;

public interface IBoarderService {

	public void execute(Model model);
	
}
