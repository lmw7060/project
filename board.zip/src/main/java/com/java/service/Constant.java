package com.java.service;

import org.apache.ibatis.session.SqlSession;

public class Constant {
	public static SqlSession sqlSession;
}
