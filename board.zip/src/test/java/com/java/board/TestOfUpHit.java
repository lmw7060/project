package com.java.board;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.java.board.dao.IDao;
import com.java.board.dto.BDto;

public class TestOfUpHit {
	private IDao testdao;
	private BDto testbdto;
	
	@Test
	public void write가되는가() {
		testdao.write("김무무", "아무무", "헤헤헤");
		assertEquals(null, "김무무");
	}
}
