package com.rp.dao;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.rp.dto.MemberDto;

public interface MemberDao {
	//로그인기능
	MemberDto login(MemberDto dto) throws Exception;
	//회원가입기능
	void insert(MemberDto dto) throws Exception;
	//회원정보수정기능
	void update(MemberDto dto) throws Exception;
	//회원삭제
	void delete(String id) throws Exception;
	//로그아웃
	void logout(HttpSession session) throws Exception;
	//중복된 아이디확인
	MemberDto idcheck(String id) throws Exception;
	//수정보조
	MemberDto selectById(String id) throws Exception;
	//회원가입보조
	List<MemberDto> selectAll() throws Exception;
	//회원삭제
	List<MemberDto> selectName(String name) throws Exception;
}

