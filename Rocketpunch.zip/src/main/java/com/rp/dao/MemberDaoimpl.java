package com.rp.dao;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.rp.dto.MemberDto;

@Repository
public class MemberDaoimpl implements MemberDao {

	@Inject
	private SqlSession session;
	
	@Override//로그인
	public MemberDto login(MemberDto dto) throws Exception {
		// TODO Auto-generated method stub
		return session.selectOne("memberMapper.login", dto);
	}

	@Override//회원가입기능
	public void insert(MemberDto dto) throws Exception {
		session.update("memberMapper.insertMember",dto);
	}

	@Override//회원정보수정기능
	public void update(MemberDto dto) throws Exception {
		session.update("memberMapper.updateMember",dto);
	}

	@Override//회원삭제
	public void delete(String id) throws Exception {
		session.update("memberMapper.deleteMember", id);
	}

	@Override//로그아웃
	public void logout(HttpSession session) throws Exception {
		// TODO Auto-generated method stub
	}

	@Override//중복된 아이디확인
	public MemberDto idcheck(String id) throws Exception {
		return session.selectOne("memberMapper.idCheck",id);
	}

	@Override//수정보조
	public MemberDto selectById(String id) throws Exception {
		return session.selectOne("memberMapper.selectMember",id);
	}

	@Override//회원가입보조
	public List<MemberDto> selectAll() throws Exception {
		return session.selectList("memberMapper.selectAllMember");
	}

	@Override//회원삭제
	public List<MemberDto> selectName(String name) throws Exception {
		return session.selectList("memberMapper.selectName",name);
	}

}
