package com.rp.dto;

public class ReservationDto {
	int ReservationNo;
	int SeatNo;
	int RestaurantNo;
	int TypeNo;
	int MenuNo;
	String ReservationTime;//timestamp타입
	String Id;
	
	public ReservationDto() {}

	public ReservationDto(int reservationNo, int seatNo, int restaurantNo, int typeNo, int menuNo,
			String reservationTime, String id) {
		super();
		ReservationNo = reservationNo;
		SeatNo = seatNo;
		RestaurantNo = restaurantNo;
		TypeNo = typeNo;
		MenuNo = menuNo;
		ReservationTime = reservationTime;
		Id = id;
	}

	public int getReservationNo() {
		return ReservationNo;
	}

	public void setReservationNo(int reservationNo) {
		ReservationNo = reservationNo;
	}

	public int getSeatNo() {
		return SeatNo;
	}

	public void setSeatNo(int seatNo) {
		SeatNo = seatNo;
	}

	public int getRestaurantNo() {
		return RestaurantNo;
	}

	public void setRestaurantNo(int restaurantNo) {
		RestaurantNo = restaurantNo;
	}

	public int getTypeNo() {
		return TypeNo;
	}

	public void setTypeNo(int typeNo) {
		TypeNo = typeNo;
	}

	public int getMenuNo() {
		return MenuNo;
	}

	public void setMenuNo(int menuNo) {
		MenuNo = menuNo;
	}

	public String getReservationTime() {
		return ReservationTime;
	}

	public void setReservationTime(String reservationTime) {
		ReservationTime = reservationTime;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}
}
