package com.rp.dto;

public class MemberDto {
	String Id;
	String Pw;
	String Name;
	String Email;
	String Grade;
	
	public MemberDto() {}
	public MemberDto(String id, String pw, String name, String email, String grade) {
		super();
		Id = id;
		Pw = pw;
		Name = name;
		Email = email;
		Grade = grade;
	}
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getPw() {
		return Pw;
	}
	public void setPw(String pw) {
		Pw = pw;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getGrade() {
		return Grade;
	}
	public void setGrade(String grade) {
		Grade = grade;
	}
	
	
	
}