package com.rp.dto;

import java.sql.Timestamp;

public class RCheck {
		String FoodType;
		String RestaurantName;
		String MenuName;
		String Seat;
		Timestamp ReservationTime;
		int SeatNo;
		int TypeNo;
		int RestaurantNo;
		int MenuNo;
		int ReservationNo;
		String id;
		
		public RCheck() {}

		public RCheck(String foodType, String restaurantName, String menuName, String seat, Timestamp reservationTime,
				int seatNo, int typeNo, int restaurantNo, int menuNo, int reservationNo, String id) {
			super();
			FoodType = foodType;
			RestaurantName = restaurantName;
			MenuName = menuName;
			Seat = seat;
			ReservationTime = reservationTime;
			SeatNo = seatNo;
			TypeNo = typeNo;
			RestaurantNo = restaurantNo;
			MenuNo = menuNo;
			ReservationNo = reservationNo;
			this.id = id;
		}

		public String getFoodType() {
			return FoodType;
		}

		public void setFoodType(String foodType) {
			FoodType = foodType;
		}

		public String getRestaurantName() {
			return RestaurantName;
		}

		public void setRestaurantName(String restaurantName) {
			RestaurantName = restaurantName;
		}

		public String getMenuName() {
			return MenuName;
		}

		public void setMenuName(String menuName) {
			MenuName = menuName;
		}

		public String getSeat() {
			return Seat;
		}

		public void setSeat(String seat) {
			Seat = seat;
		}

		public Timestamp getReservationTime() {
			return ReservationTime;
		}

		public void setReservationTime(Timestamp reservationTime) {
			ReservationTime = reservationTime;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public int getSeatNo() {
			return SeatNo;
		}

		public void setSeatNo(int seatNo) {
			SeatNo = seatNo;
		}

		public int getTypeNo() {
			return TypeNo;
		}

		public void setTypeNo(int typeNo) {
			TypeNo = typeNo;
		}

		public int getRestaurantNo() {
			return RestaurantNo;
		}

		public void setRestaurantNo(int restaurantNo) {
			RestaurantNo = restaurantNo;
		}

		public int getMenuNo() {
			return MenuNo;
		}

		public void setMenuNo(int menuNo) {
			MenuNo = menuNo;
		}

		public int getReservationNo() {
			return ReservationNo;
		}

		public void setReservationNo(int reservationNo) {
			ReservationNo = reservationNo;
		}
		
		
}
