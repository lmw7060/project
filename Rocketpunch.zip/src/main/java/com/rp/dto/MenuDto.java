package com.rp.dto;

public class MenuDto {
	int MenuNo;
	int RestaurantNo;
	int TypeNo;
	String MenuName;
	String MenuPrice;
	
	public MenuDto() {}

	public MenuDto(int menuNo, int restaurantNo, int typeNo, String menuName, String menuPrice) {
		super();
		MenuNo = menuNo;
		RestaurantNo = restaurantNo;
		TypeNo = typeNo;
		MenuName = menuName;
		MenuPrice = menuPrice;
	}

	public int getMenuNo() {
		return MenuNo;
	}

	public void setMenuNo(int menuNo) {
		MenuNo = menuNo;
	}

	public int getRestaurantNo() {
		return RestaurantNo;
	}

	public void setRestaurantNo(int restaurantNo) {
		RestaurantNo = restaurantNo;
	}

	public int getTypeNo() {
		return TypeNo;
	}

	public void setTypeNo(int typeNo) {
		TypeNo = typeNo;
	}

	public String getMenuName() {
		return MenuName;
	}

	public void setMenuName(String menuName) {
		MenuName = menuName;
	}

	public String getMenuPrice() {
		return MenuPrice;
	}

	public void setMenuPrice(String menuPrice) {
		MenuPrice = menuPrice;
	}
}
