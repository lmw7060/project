package com.rp.dto;

public class SeatDto {
	int SeatNo;
	int RestaurantNo;
	int TypeNo;
	int SeatNum;
	String Seat;
	
	public SeatDto() {}

	public SeatDto(int seatNo, int restaurantNo, int typeNo, int seatNum, String seat) {
		super();
		SeatNo = seatNo;
		RestaurantNo = restaurantNo;
		TypeNo = typeNo;
		SeatNum = seatNum;
		Seat = seat;
	}

	public int getSeatNo() {
		return SeatNo;
	}

	public void setSeatNo(int seatNo) {
		SeatNo = seatNo;
	}

	public int getRestaurantNo() {
		return RestaurantNo;
	}

	public void setRestaurantNo(int restaurantNo) {
		RestaurantNo = restaurantNo;
	}

	public int getTypeNo() {
		return TypeNo;
	}

	public void setTypeNo(int typeNo) {
		TypeNo = typeNo;
	}

	public int getSeatNum() {
		return SeatNum;
	}

	public void setSeatNum(int seatNum) {
		SeatNum = seatNum;
	}

	public String getSeat() {
		return Seat;
	}

	public void setSeat(String seat) {
		Seat = seat;
	}
}
