package com.rp.dto;

import java.util.Date;

public class ReviewDto {
	int ReviewNo;
	String Title;
	String Content;
	Date ReviewDate;
	int RestaurantNo;
	int TypeNo;
	String Id;
	
	public ReviewDto() {}

	public ReviewDto(int reviewNo, String title, String content, Date reviewDate, int restaurantNo, int typeNo,
			String id) {
		super();
		ReviewNo = reviewNo;
		Title = title;
		Content = content;
		ReviewDate = reviewDate;
		RestaurantNo = restaurantNo;
		TypeNo = typeNo;
		Id = id;
	}

	public int getReviewNo() {
		return ReviewNo;
	}

	public void setReviewNo(int reviewNo) {
		ReviewNo = reviewNo;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getContent() {
		return Content;
	}

	public void setContent(String content) {
		Content = content;
	}

	public Date getReviewDate() {
		return ReviewDate;
	}

	public void setReviewDate(Date reviewDate) {
		ReviewDate = reviewDate;
	}

	public int getRestaurantNo() {
		return RestaurantNo;
	}

	public void setRestaurantNo(int restaurantNo) {
		RestaurantNo = restaurantNo;
	}

	public int getTypeNo() {
		return TypeNo;
	}

	public void setTypeNo(int typeNo) {
		TypeNo = typeNo;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}
}
