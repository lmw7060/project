package com.rp.dto;

public class TypeDto {
	int TypeNo;
	String FoodType;
	
	public TypeDto() {}

	public TypeDto(int typeNo, String foodType) {
		super();
		TypeNo = typeNo;
		FoodType = foodType;
	}

	public int getTypeNo() {
		return TypeNo;
	}

	public void setTypeNo(int typeNo) {
		TypeNo = typeNo;
	}

	public String getFoodType() {
		return FoodType;
	}

	public void setFoodType(String foodType) {
		FoodType = foodType;
	}
	
}
