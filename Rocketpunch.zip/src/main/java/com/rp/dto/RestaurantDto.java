package com.rp.dto;

public class RestaurantDto {
	int RestaurantNo;
	int TypeNo;
	String RestaurantName;
	String Id;
	int Hit;
	
	public RestaurantDto() {}
	
	public RestaurantDto(int restaurantNo, int typeNo, String restaurantName, String id, int hit) {
		super();
		RestaurantNo = restaurantNo;
		TypeNo = typeNo;
		RestaurantName = restaurantName;
		Id = id;
		Hit = hit;
	}

	public int getRestaurantNo() {
		return RestaurantNo;
	}

	public void setRestaurantNo(int restaurantNo) {
		RestaurantNo = restaurantNo;
	}

	public int getTypeNo() {
		return TypeNo;
	}

	public void setTypeId(int typeNo) {
		TypeNo = typeNo;
	}

	public String getRestaurantName() {
		return RestaurantName;
	}

	public void setRestaurantName(String restaurantName) {
		RestaurantName = restaurantName;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public int getHit() {
		return Hit;
	}

	public void setHit(int hit) {
		Hit = hit;
	}
}
