package com.rp.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.rp.dao.RestaurantDao;
import com.rp.dto.MenuDto;
import com.rp.dto.RCheck;
import com.rp.dto.ReservationDto;
import com.rp.dto.RestaurantDto;
import com.rp.dto.ReviewDto;
import com.rp.dto.SeatDto;
import com.rp.dto.TypeDto;

@Service
public class RestaurantServiceimpl implements RestaurantService {
	
	@Inject
	private RestaurantDao dao;
	
	@Override
	public void insert(MenuDto MDto) throws Exception {
		dao.insert(MDto);
		
	}

	@Override
	public void update(MenuDto MDto) throws Exception {
		dao.update(MDto);
		
	}

	@Override
	public void deleteMenu(int menuNo) throws Exception {
		dao.deleteMenu(menuNo);
		
	}

	@Override
	public void insert(ReviewDto ReDto) throws Exception {
		dao.insert(ReDto);
		
	}

	@Override
	public void update(ReviewDto ReDto) throws Exception {
		dao.update(ReDto);
		
	}

	@Override
	public void deleteReview(int reviewNo) throws Exception {
		dao.deleteReview(reviewNo);
	}
	@Override
	public void deleteReview1(int restaurantNo) throws Exception {
		dao.deleteReview1(restaurantNo);
	}
	@Override
	public void deleteReview2(String id) throws Exception {
		dao.deleteReview2(id);
	}

	@Override
	public void insert(SeatDto SDto) throws Exception {
		dao.insert(SDto);
		
	}

	@Override
	public void update(SeatDto SDto) throws Exception {
		dao.update(SDto);
		
	}

	@Override
	public void deleteSeat(int seatNo) throws Exception {
		dao.deleteSeat(seatNo);
		
	}

	@Override
	public void insert(ReservationDto ResDto) throws Exception {
		dao.insert(ResDto);
		
	}

	@Override
	public void update(ReservationDto ResDto) throws Exception {
		dao.update(ResDto);
		
	}

	@Override
	public void deleteReservation(int reservationNo) throws Exception {
		dao.deleteReservation(reservationNo);
		
	}

	@Override
	public void insert(RestaurantDto RDto) throws Exception {
		dao.insert(RDto);	
	}
	@Override
	public void insert1(RestaurantDto RDto) throws Exception {
		dao.insert1(RDto);	
	}
	@Override
	public void insert2(RestaurantDto RDto) throws Exception {
		dao.insert2(RDto);
		
	}
	@Override
	public void insert5(RestaurantDto RDto) throws Exception {
		dao.insert5(RDto);
		
	}
	@Override
	public void insert7(RestaurantDto RDto) throws Exception {
		dao.insert7(RDto);
		
	}

	@Override
	public void update(RestaurantDto RDto) throws Exception {
		dao.update(RDto);
		
	}

	@Override
	public void deleteRestaurant(int restaurantNo) throws Exception {
		dao.deleteRestaurant(restaurantNo);
		
	}

	@Override
	public void upHit1(int restaurantNo) throws Exception {
		dao.upHit1(restaurantNo);
		
	}
	@Override
	public void upHit2(int restaurantNo) throws Exception {
		dao.upHit2(restaurantNo);
		
	}
	@Override
	public void upHit3(int restaurantNo) throws Exception {
		dao.upHit3(restaurantNo);
		
	}
	@Override
	public void upHit4(int restaurantNo) throws Exception {
		dao.upHit4(restaurantNo);
		
	}
	
	@Override
	public void insert(TypeDto TDto) throws Exception {
		dao.insert(TDto);
		
	}

	@Override
	public void update(TypeDto TDto) throws Exception {
		dao.update(TDto);
		
	}

	@Override
	public void deleteType(int typeNo) throws Exception {
		dao.deleteType(typeNo);
		
	}

	@Override
	public List<MenuDto> selectMAll() throws Exception {
		return dao.selectMAll();
	}

	@Override
	public List<ReviewDto> selectReAll() throws Exception {
		return dao.selectReAll();
	}

	@Override
	public List<SeatDto> selectSAll() throws Exception {
		return dao.selectSAll();
	}

	@Override
	public List<ReservationDto> selectResAll() throws Exception {
		return dao.selectResAll();
	}

	@Override
	public List<RestaurantDto> selectRAll() throws Exception {
		return dao.selectRAll();
	}

	@Override
	public List<TypeDto> selectTAll() throws Exception {
		return dao.selectTAll();
	}

	@Override
	public List<MenuDto> selectMenuNo(int menuNo) throws Exception {
		return dao.selectMenuNo(menuNo);
	}

	@Override
	public List<ReviewDto> selectReviewNo(int reviewNo) throws Exception {
		return dao.selectReviewNo(reviewNo);
	}
	@Override
	public List<ReviewDto> select1(int restaurantNo) throws Exception {
		return dao.select1(restaurantNo);
	}

	@Override
	public List<SeatDto> selectSeatNo(int seatNo) throws Exception {
		return dao.selectSeatNo(seatNo);
	}

	@Override
	public List<ReservationDto> selectReservationNo(int reservationNo) throws Exception {
		return dao.selectReservationNo(reservationNo);
	}

	@Override
	public List<RestaurantDto> selectRestaurantNo(int restaurantNo) throws Exception {
		return dao.selectRestaurantNo(restaurantNo);
	}

	@Override
	public List<TypeDto> selectTypeNo(int typeNo) throws Exception {
		return dao.selectTypeNo(typeNo);
	}

	@Override
	public List<RCheck> rCheck(String id) throws Exception {
		return dao.rCheck(id);
		
	}

}
