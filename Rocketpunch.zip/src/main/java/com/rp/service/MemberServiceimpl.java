package com.rp.service;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.rp.dto.MemberDto;
import com.rp.dao.MemberDao;

@Service
public class MemberServiceimpl implements MemberService {

	@Inject
	private MemberDao dao;
	
	@Override//로그인
	public MemberDto login(MemberDto dto) throws Exception {
		return dao.login(dto);
	}

	@Override//회원가입기능
	public void insert(MemberDto dto) throws Exception {
		dao.insert(dto);
	}

	@Override//회원정보수정기능
	public void update(MemberDto dto) throws Exception {
		dao.update(dto);
	}

	@Override//회원삭제
	public void delete(String id) throws Exception {
		dao.delete(id);
	}

	@Override//로그아웃
	public void logout(HttpSession session) throws Exception {
		session.invalidate();
	}

	@Override//중복된 아이디확인
	public MemberDto idcheck(String id) throws Exception {
		return dao.idcheck(id);
	}

	@Override//수정보조
	public MemberDto selectById(String id) throws Exception {
		return dao.selectById(id);
	}

	@Override//회원가입보조
	public List<MemberDto> selectAll() throws Exception {
		return dao.selectAll();
	}

	@Override//회원삭제보조
	public List<MemberDto> selectName(String name) throws Exception {
		return dao.selectName(name);
	}

}
