package com.rp.service;

import java.util.List;

import com.rp.dto.*;

public interface RestaurantService {
	//메뉴추가기능
	void insert(MenuDto MDto) throws Exception;
	//메뉴수정기능
	void update(MenuDto MDto) throws Exception;
	//메뉴삭제기능
	void deleteMenu(int menuNo) throws Exception;
	//리뷰추가기능
	void insert(ReviewDto ReDto) throws Exception;
	//리뷰수정기능
	void update(ReviewDto ReDto) throws Exception;
	//리뷰삭제기능
	void deleteReview(int reviewNo) throws Exception;
	void deleteReview1(int restaurantNo) throws Exception;
	void deleteReview2(String id) throws Exception;
	//자리추가기능
	void insert(SeatDto SDto) throws Exception;
	//자리수정기능
	void update(SeatDto SDto) throws Exception;
	//자리삭제기능
	void deleteSeat(int seatNo) throws Exception;
	//예약추가기능
	void insert(ReservationDto ResDto) throws Exception;
	//예약수정기능
	void update(ReservationDto ResDto) throws Exception;
	//예약삭제기능
	void deleteReservation(int reservationNo) throws Exception;
	//식당추가기능
	void insert(RestaurantDto RDto) throws Exception;
	void insert1(RestaurantDto RDto) throws Exception;
	void insert2(RestaurantDto RDto) throws Exception;
	void insert5(RestaurantDto RDto) throws Exception;
	void insert7(RestaurantDto RDto) throws Exception;
	//식당수정기능
	void update(RestaurantDto RDto) throws Exception;
	//식당삭제기능
	void deleteRestaurant(int restaurantNo) throws Exception;
	//조회수기능
	void upHit1(int restaurantNo) throws Exception;
	void upHit2(int restaurantNo) throws Exception;
	void upHit3(int restaurantNo) throws Exception;
	void upHit4(int restaurantNo) throws Exception;
	//분류추가기능
	void insert(TypeDto TDto) throws Exception;
	//분류수정기능
	void update(TypeDto TDto) throws Exception;
	//분류삭제기능
	void deleteType(int typeNo) throws Exception;
	// 메뉴리스트
	List<MenuDto> selectMAll() throws Exception;
	// 리뷰리스트
	List<ReviewDto> selectReAll() throws Exception;
	// 자리리스트
	List<SeatDto> selectSAll() throws Exception;
	// 예약리스트
	List<ReservationDto> selectResAll() throws Exception;
	// 식당리스트
	List<RestaurantDto> selectRAll() throws Exception;
	// 종류리스트
	List<TypeDto> selectTAll() throws Exception;
	// 메뉴선택
	List<MenuDto> selectMenuNo(int menuNo) throws Exception;
	// 리뷰선택
	List<ReviewDto> selectReviewNo(int reviewNo) throws Exception;
	List<ReviewDto> select1(int restaurantNo) throws Exception;
	// 자리선택
	List<SeatDto> selectSeatNo(int seatNo) throws Exception;
	// 예약선택
	List<ReservationDto> selectReservationNo(int reservationNo) throws Exception;
	// 식당선택
	List<RestaurantDto> selectRestaurantNo(int restaurantNo) throws Exception;
	// 종류선택
	List<TypeDto> selectTypeNo(int typeNo) throws Exception;
	// 예약확인
	List<RCheck> rCheck(String id) throws Exception;
}
