package com.rp.controller;

import java.util.List;

import javax.inject.Inject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rp.dto.RestaurantDto;
import com.rp.service.MemberService;
import com.rp.service.RestaurantService;


@Controller
public class HomeController {
	
	@Inject
	MemberService service;
	RestaurantService service2;
	
	@Inject
	RestaurantService Rservice;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		
		return "home";
	}
	
}

