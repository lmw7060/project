package com.rp.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rp.dto.RCheck;
import com.rp.dto.ReservationDto;
import com.rp.service.RestaurantService;

@Controller
public class ReservationController {
	@Inject
	public RestaurantService service;

	@RequestMapping(value = "/reservationlist")
	public String reservationlist(Model model) throws Exception {
		List<ReservationDto> reservationlist = service.selectResAll();
		model.addAttribute("reservationList", reservationlist);
		return "reservation/reservationlist";
	}

	@RequestMapping(value = "/reservationplus", method = RequestMethod.GET)
	public String reservationplus(Model model) throws Exception {
		List<ReservationDto> reservationlist = service.selectResAll();
		model.addAttribute("reservationList", reservationlist);
		return "reservation/reservationplus";
	}

	@RequestMapping(value = "/reservationplus", method = RequestMethod.POST)
	public String reservationplus(ReservationDto Resdto) throws Exception {
		service.insert(Resdto);
		return "reservation/reservationplus";
	}

	@RequestMapping(value = "/deleteReservation", method = RequestMethod.GET)
	public String deleteReservation(int reservationNo) throws Exception {
		service.deleteReservation(reservationNo);
		return "redirect:reservationlist";
	}
	
	@RequestMapping(value = "/rCheck")
	public String rCheck(Model model,String id) throws Exception {
		List<RCheck> rCheck = service.rCheck("lhk");
		model.addAttribute("rCheck", rCheck);
		return "reservation/rCheck";
	}
	@RequestMapping(value = "/seat1", method = RequestMethod.GET)
	public String seat1(Model model) throws Exception {
		List<ReservationDto> reservationlist = service.selectResAll();
		model.addAttribute("reservationList", reservationlist);
		return "reservation/seat1";
	}

	@RequestMapping(value = "/seat1", method = RequestMethod.POST)
	public String seat1(ReservationDto Resdto) throws Exception {
		service.insert(Resdto);
		return "reservation/confirmation";
	}

	
}
