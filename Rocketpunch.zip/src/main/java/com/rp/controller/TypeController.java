package com.rp.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rp.dto.RestaurantDto;
import com.rp.dto.TypeDto;
import com.rp.service.RestaurantService;

@Controller
public class TypeController {
	@Inject
	public RestaurantService service;
	@RequestMapping(value="/type1",method=RequestMethod.GET)
	public String type1()throws Exception{
		
		return "type/type1";
	}
	@RequestMapping(value="/type7",method=RequestMethod.GET)
	public String type7()throws Exception{
		
		return "type/type7";
	}
	@RequestMapping(value="/type2",method=RequestMethod.GET)
	public String type2()throws Exception{
		
		return "type/type2";
	}
	@RequestMapping(value="/type5",method=RequestMethod.GET)
	public String type5()throws Exception{
		
		return "type/type5";
	}

	@RequestMapping(value="/typelist")
	public String typelist(Model model) throws Exception{
		List<TypeDto> typelist = service.selectTAll();
		model.addAttribute("typeList",typelist);
		return "type/typelist";
	}		
	
	@RequestMapping(value="/typeplus",method=RequestMethod.GET)
	public String typeplus(Model model) throws Exception{
		List<TypeDto>typelist = service.selectTAll();
		model.addAttribute("typeList", typelist);
		return "type/typeplus";
	}
	
	@RequestMapping(value="/typeplus",method=RequestMethod.POST)
	public String typeplus(TypeDto Tdto) throws Exception{
		service.insert(Tdto);
		return "type/typeplus";
	}
	@RequestMapping(value="/deleteType",method=RequestMethod.GET)
	public String deleteType(int typeNo)throws Exception{
		service.deleteType(typeNo);
		return "redirect:typelist";
	}
}
