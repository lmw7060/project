package com.rp.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rp.dto.RestaurantDto;
import com.rp.service.RestaurantService;
@Controller
public class RestaurantController {
	
	@Inject
	public RestaurantService service;

	@RequestMapping(value="/restaurantlist")
	public String restaurantlist(Model model) throws Exception{
		List<RestaurantDto> restaurantlist = service.selectRAll();
		model.addAttribute("restaurantList",restaurantlist);
		return "restaurant/restaurantlist";
	}
	
	@RequestMapping(value="/restaurantplus1",method=RequestMethod.GET)
	public String restaurantplus1(Model model) throws Exception{
		List<RestaurantDto>restaurantlist = service.selectRAll();
		model.addAttribute("restaurantList", restaurantlist);
		return "restaurant/restaurantplus1";
	}
	
	@RequestMapping(value="/restaurantplus1",method=RequestMethod.POST)
	public String restaurantplus1(RestaurantDto Rdto) throws Exception{
		service.insert1(Rdto);
		return "restaurant/restaurantplus1";
	}
	@RequestMapping(value="/restaurantplus2",method=RequestMethod.GET)
	public String restaurantplus2(Model model) throws Exception{
		List<RestaurantDto>restaurantlist = service.selectRAll();
		model.addAttribute("restaurantList", restaurantlist);
		return "restaurant/restaurantplus2";
	}
	
	@RequestMapping(value="/restaurantplus2",method=RequestMethod.POST)
	public String restaurantplus2(RestaurantDto Rdto) throws Exception{
		service.insert2(Rdto);
		return "restaurant/restaurantplus2";
	}
	@RequestMapping(value="/restaurantplus5",method=RequestMethod.GET)
	public String restaurantplus5(Model model) throws Exception{
		List<RestaurantDto>restaurantlist = service.selectRAll();
		model.addAttribute("restaurantList", restaurantlist);
		return "restaurant/restaurantplus5";
	}
	
	@RequestMapping(value="/restaurantplus5",method=RequestMethod.POST)
	public String restaurantplus5(RestaurantDto Rdto) throws Exception{
		service.insert5(Rdto);
		return "restaurant/restaurantplus5";
	}
	@RequestMapping(value="/restaurantplus7",method=RequestMethod.GET)
	public String restaurantplus7(Model model) throws Exception{
		List<RestaurantDto>restaurantlist = service.selectRAll();
		model.addAttribute("restaurantList", restaurantlist);
		return "restaurant/restaurantplus7";
	}
	
	@RequestMapping(value="/restaurantplus7",method=RequestMethod.POST)
	public String restaurantplus7(RestaurantDto Rdto) throws Exception{
		service.insert7(Rdto);
		return "restaurant/restaurantplus7";
	}
	@RequestMapping(value="/deleteRestaurant",method=RequestMethod.GET)
	public String deleteRestaurant(int restaurantNo)throws Exception{
		service.deleteRestaurant(restaurantNo);
		return "redirect:restaurantlist";
	}
	@RequestMapping(value="/restaurant1",method=RequestMethod.GET)
	public String restaurant1()throws Exception{
		service.upHit1(1);
		return "restaurant/restaurant1";
	}
	@RequestMapping(value="/restaurant2",method=RequestMethod.GET)
	public String restaurant2()throws Exception{
		service.upHit2(24);
		return "restaurant/restaurant2";
	}
	@RequestMapping(value="/restaurant3",method=RequestMethod.GET)
	public String restaurant3()throws Exception{
		service.upHit3(25);
		return "restaurant/restaurant3";
	}
	@RequestMapping(value="/restaurant4",method=RequestMethod.GET)
	public String restaurant4()throws Exception{
		service.upHit4(26);
		return "restaurant/restaurant4";
	}
	@RequestMapping(value="/restaurant5",method=RequestMethod.GET)
	public String restaurant5()throws Exception{
		service.upHit4(37);
		return "restaurant/restaurant5";
	}
	@RequestMapping(value="/restaurant6",method=RequestMethod.GET)
	public String restaurant6()throws Exception{
		service.upHit4(23);
		return "restaurant/restaurant6";
	}
	@RequestMapping(value="/restaurant7",method=RequestMethod.GET)
	public String restaurant7()throws Exception{
		service.upHit4(33);
		return "restaurant/restaurant7";
	}
}
