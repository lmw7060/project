package com.rp.controller;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rp.dto.MemberDto;
import com.rp.service.MemberService;

@Controller
public class MemberController {
	
	@Inject
	private MemberService service;
	
	@RequestMapping(value="/list")
	public String list(Model model) throws Exception{
		List<MemberDto> memberList = service.selectAll();
		model.addAttribute("memberList",memberList);
		return "member/list";
	}
	
	@RequestMapping(value="/join",method=RequestMethod.GET)
	public String join(Model model) throws Exception{
		List<MemberDto>memberList = service.selectAll();
		model.addAttribute("memberList", memberList);
		
		return "member/join";
	}
	
	@RequestMapping(value="/join",method=RequestMethod.POST)
	public String join(MemberDto dto) throws Exception{
		System.out.println("Join화면	");
		service.insert(dto); 
		return "member/login";
	}
	
	@RequestMapping(value="/update",method=RequestMethod.GET)
	public String update(String id, Model model) throws Exception{
		MemberDto member = service.selectById(id);
		model.addAttribute("member",member);
		return "member/update";
	}
	
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String update(MemberDto dto) throws Exception{
		service.update(dto);
		return "redirect:/";
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String delete(String id)throws Exception{
		service.delete(id);
		return "redirect:/";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET )
	public String login() throws Exception {
		return "member/login";
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(MemberDto dto,Model model, HttpServletRequest req, RedirectAttributes rttr)throws Exception{
		System.out.println("Login화면");
		
		  HttpSession session = req.getSession();
		  MemberDto login = service.login(dto);
		  
		  if(login==null) { session.setAttribute("member", null);
		  rttr.addFlashAttribute("msg",false);
		  
		  return "redirect:/member/login";
		  
		  }else { session.setAttribute("member", login); } return "redirect:/";
		 
		
		
		
	}
	
	@RequestMapping(value="/logout")
	public String logOut(Model model, HttpSession session)throws Exception{
		service.logout(session);
		return "redirect:/";
	}
	

}
