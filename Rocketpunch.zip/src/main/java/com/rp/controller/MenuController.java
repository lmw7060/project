package com.rp.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rp.dto.MenuDto;
import com.rp.service.RestaurantService;

@Controller
public class MenuController {
	@Inject
	public RestaurantService service;
	@RequestMapping(value="/menulist")
	public String menulist(Model model) throws Exception{
		List<MenuDto> menulist = service.selectMAll();
		model.addAttribute("menuList",menulist);
		return "menu/menulist";
	}
	@RequestMapping(value="/menuplus",method=RequestMethod.GET)
	public String menuplus(Model model) throws Exception{
		List<MenuDto>menulist = service.selectMAll();
		model.addAttribute("menuList", menulist);
		return "menu/menuplus";
	}
	
	@RequestMapping(value="/menuplus",method=RequestMethod.POST)
	public String menuplus(MenuDto Mdto) throws Exception{
		service.insert(Mdto);
		return "menu/menuplus";
	}
	@RequestMapping(value="/deleteMenu",method=RequestMethod.GET)
	public String deleteMenu(int menuNo)throws Exception{
		service.deleteMenu(menuNo);
		return "redirect:menulist";
	}
}
