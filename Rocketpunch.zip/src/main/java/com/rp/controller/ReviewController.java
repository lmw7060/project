package com.rp.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rp.dto.ReviewDto;
import com.rp.service.RestaurantService;

@Controller
public class ReviewController {

	@Inject
	public RestaurantService service;
	@RequestMapping(value="/reviewlist")
	public String reviewlist(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.selectReAll();
		model.addAttribute("reviewList",reviewlist);
		return "review/reviewlist";
	}		
	
	@RequestMapping(value="/reviewplus",method=RequestMethod.GET)
	public String reviewplus(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.selectReAll();
		model.addAttribute("reviewList", reviewlist);
		return "review/reviewplus";
	}
	
	@RequestMapping(value="/reviewplus",method=RequestMethod.POST)
	public String reviewplus(ReviewDto Redto) throws Exception{
		service.insert(Redto);
		return "review/reviewplus";
	}
	@RequestMapping(value="/deleteReview",method=RequestMethod.GET)
	public String deleteReview(int reviewNo)throws Exception{
		service.deleteReview(reviewNo);
		return "redirect:reviewlist";
	}
	@RequestMapping(value="/review1")
	public String review1(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.select1(1);
		model.addAttribute("review1",reviewlist);
		return "review/review1";
	}
	@RequestMapping(value="/reviewplus1",method=RequestMethod.GET)
	public String reviewplus1(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.selectReAll();
		model.addAttribute("reviewList", reviewlist);
		return "review/reviewplus1";
	}
	@RequestMapping(value="/reviewplus1",method=RequestMethod.POST)
	public String reviewplus1(ReviewDto Redto) throws Exception{
		service.insert(Redto);
		return "review/reviewplus1";
	}
	@RequestMapping(value="/deleteReview1",method=RequestMethod.GET)
	public String deleteReview1(String id)throws Exception{
		service.deleteReview2(id);
		return "redirect:review1";
	}
	@RequestMapping(value="/review2")
	public String review2(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.select1(24);
		model.addAttribute("review1",reviewlist);
		return "review/review2";
	}
	@RequestMapping(value="/reviewplus2",method=RequestMethod.GET)
	public String reviewplus2(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.selectReAll();
		model.addAttribute("reviewList", reviewlist);
		return "review/reviewplus2";
	}
	@RequestMapping(value="/reviewplus2",method=RequestMethod.POST)
	public String reviewplus2(ReviewDto Redto) throws Exception{
		service.insert(Redto);
		return "review/reviewplus2";
	}
	@RequestMapping(value="/deleteReview2",method=RequestMethod.GET)
	public String deleteReview2(String id)throws Exception{
		service.deleteReview2(id);
		return "redirect:review2";
	}
	@RequestMapping(value="/review3")
	public String review3(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.select1(25);
		model.addAttribute("review1",reviewlist);
		return "review/review3";
	}
	@RequestMapping(value="/reviewplus3",method=RequestMethod.GET)
	public String reviewplus3(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.selectReAll();
		model.addAttribute("reviewList", reviewlist);
		return "review/reviewplus3";
	}
	@RequestMapping(value="/reviewplus3",method=RequestMethod.POST)
	public String reviewplus3(ReviewDto Redto) throws Exception{
		service.insert(Redto);
		return "review/reviewplus3";
	}
	@RequestMapping(value="/deleteReview3",method=RequestMethod.GET)
	public String deleteReview3(String id)throws Exception{
		service.deleteReview2(id);
		return "redirect:review3";
	}
	@RequestMapping(value="/review4")
	public String review4(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.select1(26);
		model.addAttribute("review1",reviewlist);
		return "review/review4";
	}
	@RequestMapping(value="/reviewplus4",method=RequestMethod.GET)
	public String reviewplus4(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.selectReAll();
		model.addAttribute("reviewList", reviewlist);
		return "review/reviewplus4";
	}
	@RequestMapping(value="/reviewplus4",method=RequestMethod.POST)
	public String reviewplus4(ReviewDto Redto) throws Exception{
		service.insert(Redto);
		return "review/reviewplus4";
	}
	@RequestMapping(value="/deleteReview4",method=RequestMethod.GET)
	public String deleteReview4(String id)throws Exception{
		service.deleteReview2(id);
		return "redirect:review4";
	}
	@RequestMapping(value="/review5")
	public String review5(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.select1(37);
		model.addAttribute("review1",reviewlist);
		return "review/review5";
	}
	@RequestMapping(value="/reviewplus5",method=RequestMethod.GET)
	public String reviewplus5(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.selectReAll();
		model.addAttribute("reviewList", reviewlist);
		return "review/reviewplus5";
	}
	@RequestMapping(value="/reviewplus5",method=RequestMethod.POST)
	public String reviewplus5(ReviewDto Redto) throws Exception{
		service.insert(Redto);
		return "review/reviewplus5";
	}
	@RequestMapping(value="/deleteReview5",method=RequestMethod.GET)
	public String deleteReview5(String id)throws Exception{
		service.deleteReview2(id);
		return "redirect:review5";
	}
	@RequestMapping(value="/review6")
	public String review6(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.select1(23);
		model.addAttribute("review1",reviewlist);
		return "review/review6";
	}
	@RequestMapping(value="/reviewplus6",method=RequestMethod.GET)
	public String reviewplus6(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.selectReAll();
		model.addAttribute("reviewList", reviewlist);
		return "review/reviewplus6";
	}
	@RequestMapping(value="/reviewplus6",method=RequestMethod.POST)
	public String reviewplus6(ReviewDto Redto) throws Exception{
		service.insert(Redto);
		return "review/reviewplus6";
	}
	@RequestMapping(value="/deleteReview6",method=RequestMethod.GET)
	public String deleteReview6(String id)throws Exception{
		service.deleteReview2(id);
		return "redirect:review6";
	}
	@RequestMapping(value="/review7")
	public String review7(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.select1(33);
		model.addAttribute("review1",reviewlist);
		return "review/review7";
	}
	@RequestMapping(value="/reviewplus7",method=RequestMethod.GET)
	public String reviewplus7(Model model) throws Exception{
		List<ReviewDto> reviewlist = service.selectReAll();
		model.addAttribute("reviewList", reviewlist);
		return "review/reviewplus7";
	}
	@RequestMapping(value="/reviewplus7",method=RequestMethod.POST)
	public String reviewplus7(ReviewDto Redto) throws Exception{
		service.insert(Redto);
		return "review/reviewplus7";
	}
	@RequestMapping(value="/deleteReview7",method=RequestMethod.GET)
	public String deleteReview7(String id)throws Exception{
		service.deleteReview2(id);
		return "redirect:review7";
	}
}
