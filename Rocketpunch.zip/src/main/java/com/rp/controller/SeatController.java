package com.rp.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.rp.dto.SeatDto;
import com.rp.service.RestaurantService;

@Controller
public class SeatController {

	@Inject
	public RestaurantService service;
	@RequestMapping(value="/seatlist")
	public String seatlist(Model model) throws Exception{
		List<SeatDto> seatlist = service.selectSAll();
		model.addAttribute("seatList",seatlist);
		return "seat/seatlist";
	}
	@RequestMapping(value="/seatplus",method=RequestMethod.GET)
	public String seatplus(Model model) throws Exception{
		List<SeatDto>seatlist = service.selectSAll();
		model.addAttribute("seatList", seatlist);
		return "seat/seatplus";
	}
	
	@RequestMapping(value="/seatplus",method=RequestMethod.POST)
	public String seatplus(SeatDto Sdto) throws Exception{
		service.insert(Sdto);
		return "seat/seatplus";
	}
	@RequestMapping(value="/deleteSeat",method=RequestMethod.GET)
	public String deleteSeat(int seatNo)throws Exception{
		service.deleteSeat(seatNo);
		return "redirect:seatlist";
	}
	
}
