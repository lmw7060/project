package 가계부;

import java.sql.*;
import java.util.*;

public class HomeBookDAO implements IDAO<HomeBook, Long> {
	Connection conn = null;

	public HomeBookDAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.err.println("오라클드라이버가 없음!");
			System.exit(0);
		}
		try {
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", // url
					"HOMEBOOK2", // user
					"homebook2"// password
			);
		} catch (SQLException e) {
			System.err.println("url,user,password점검");
			System.exit(0);
		}
	}

	@Override
	public boolean isExists(Long key) throws Exception {
		String sql = "select * from homebook where serialno=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setLong(1, key);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			conn.close();
			return true;
		}
		conn.close();
		return false;
	}

	@Override
	public boolean insert(HomeBook t) throws Exception {
		String sql = "insert into homebook values" + "(SEQ_HOMEBOOK.nextval,TO_DATE(?,'YY/MM/DD'),?,?,?,?,?,?,?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, t.getDay());
		pstmt.setString(2, t.getSection());
		pstmt.setString(3, t.getRemark());
		pstmt.setLong(4, t.getRevenue());
		pstmt.setLong(5, t.getExpense());
		pstmt.setString(6, t.getTitleid());
		pstmt.setString(7, t.getUserid());
		pstmt.setString(8, t.getTitle());
		int res = pstmt.executeUpdate();
		conn.close();
		return res > 0;
	}

	@Override
	public boolean delete(Long key) throws Exception {
		// 사전점검
		// boolean is = isExists(key);
		// if(!is) return false;
		String sql = "delete homebook where serialno=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setLong(1, key);
		int res = pstmt.executeUpdate();
		conn.close();
		return res > 0;
	}

	@Override
	public boolean update(HomeBook t) throws Exception {
		String sql = "update homebook set day=to_date(?,'RRMMDD'), userid=?,titleid=?,section=?,revenue=?,expense=?,"
				+ "remark=? where serialno=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, t.getDay());
		pstmt.setString(2, t.getUserid());
		pstmt.setString(3, t.getTitleid());
		pstmt.setString(4, t.getSection());
		pstmt.setLong(5, t.getRevenue());
		pstmt.setLong(6, t.getExpense());
		pstmt.setString(7, t.getRemark());
		pstmt.setLong(8, t.getSerialno());
		int res = pstmt.executeUpdate();
		conn.close();
		return res == 1;// or res>0
	}

	@Override
	public HomeBook select(Long key) throws Exception {
		String sql = "select * from homebook where serialno=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setLong(1, key);
		ResultSet rs = pstmt.executeQuery();
		HomeBook vo = new HomeBook();
		while (rs.next()) {
			vo.setSerialno(rs.getLong("SERIALNO"));
			vo.setDay(rs.getString("DAY"));// 수정
			vo.setSection(rs.getString("SECTION"));
			vo.setRemark(rs.getString("REMARK"));
			vo.setRevenue(rs.getLong("REVENUE"));
			vo.setExpense(rs.getLong("EXPENSE"));
			vo.setTitleid(rs.getString("TITLEID"));
			vo.setUserid(rs.getString("USERID"));
		}
		conn.close();
		return vo;
	}

	@Override
	public List<HomeBook> selectByCondition(Map<Object, Object> conditionMap) throws Exception {
		String sql = "select * from homebook where ";
		String sql2 = "";
		for (Object x : conditionMap.keySet()) {
			sql2 += (String) x + "=" + conditionMap.get((String) x) + " AND ";
		}
		sql2 = sql2.substring(0, sql.length() - 5);
		sql += sql2;
		System.out.println(sql);
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		List<HomeBook> list = new ArrayList<>();
		while (rs.next()) {
			HomeBook vo = new HomeBook();
			vo.setSerialno(rs.getLong("SERIALNO"));
			vo.setDay(rs.getString("DAY"));
			vo.setSection(rs.getString("SECTION"));
			vo.setRemark(rs.getString("REMARK"));
			vo.setRevenue(rs.getLong("REVENUE"));
			vo.setExpense(rs.getLong("EXPENSE"));
			vo.setTitleid(rs.getString("TITLEID"));
			vo.setUserid(rs.getString("USERID"));
			list.add(vo);
		}
		conn.close();
		return list;
	}

	@Override
	public List<HomeBook> selectAll() throws Exception {
		String sql = "select * from homebook";
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		List<HomeBook> list = new ArrayList<>();
		while (rs.next()) {
			HomeBook vo = new HomeBook();
			vo.setSerialno(rs.getLong("SERIALNO"));
			vo.setDay(rs.getString("DAY"));
			vo.setSection(rs.getString("SECTION"));
			vo.setRemark(rs.getString("REMARK"));
			vo.setRevenue(rs.getLong("REVENUE"));
			vo.setExpense(rs.getLong("EXPENSE"));
			vo.setTitleid(rs.getString("TITLEID"));
			vo.setUserid(rs.getString("USERID"));
			list.add(vo);
		}
		return list;
	}

	@Override
	public void close() throws Exception {
		conn.close();

	}

	public long getMaxSerialno() throws Exception {
		long max = 0L;
		String sql = "select max(serialno) from homebook";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			max = rs.getLong(1);
		}
		return max;
	}

	public long getMinSerialno() throws Exception {
		long min = 0L;
		String sql = "select min(serialno) from homebook";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			min = rs.getLong(1);
		}
		// close(conn);
		return min;
	}

	public long hab() throws Exception {
		long hab=0L;
		String sql="select sum(revenue) from homebook";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			hab=rs.getLong(1);
		}
		return hab;
	}

	public long hab2() throws Exception {
		long hab2 = 0L;
		String sql = "select sum(expense) from homebook";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			hab2 = rs.getLong(1);
		}
		return hab2;
	}

	public List<HomeBook> title_load() {

		try {
			List<HomeBook> data = new ArrayList<HomeBook>();
			String sql = "SELECT title FROM accounttitle";
			PreparedStatement pstmt;
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				HomeBook vo = new HomeBook();
				vo.setTitle(rs.getString("title"));
				data.add(vo);
			}
			return data;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public String actgettitleid(String aa) {
		String sql = "SELECT titleid FROM accounttitle where title=?";
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, aa);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next())
				return rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "";
	}

	public HomeBook select2(String key) throws Exception {
		String sql = "select * from homebook where userid=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, key);
		ResultSet rs = pstmt.executeQuery();
		HomeBook vo = new HomeBook();
		while (rs.next()) {
			vo.setSerialno(rs.getLong("SERIALNO"));
			vo.setDay(rs.getString("DAY"));// 수정
			vo.setSection(rs.getString("SECTION"));
			vo.setRemark(rs.getString("REMARK"));
			vo.setRevenue(rs.getLong("REVENUE"));
			vo.setExpense(rs.getLong("EXPENSE"));
			vo.setTitleid(rs.getString("TITLEID"));
			vo.setUserid(rs.getString("USERID"));
		}
		return vo;
	}

	public List<Map<String, Object>> conditionByhomebook(String condition) throws Exception {
		String sql = "select * from homebook where " + condition;
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		while (rs.next()) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("SERIALNO", rs.getLong("SERIALNO"));
			map.put("DAY", rs.getString("DAY"));
			map.put("USERID", rs.getString("USERID"));
			map.put("TITLEID", rs.getString("TITLEID"));
			map.put("SECTION", rs.getString("SECTION"));
			map.put("REVENUE", rs.getLong("REVENUE"));
			map.put("EXPENSE", rs.getLong("EXPENSE"));
			map.put("REMARK", rs.getString("REMARK"));
			list.add(map);
		}
		return list;

	}
}
