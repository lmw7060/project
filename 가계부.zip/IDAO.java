package 가계부;

import java.util.List;
import java.util.Map;
//다오가이드라인
public interface IDAO<T,K> {
	public boolean isExists(K key) throws Exception;
	public boolean insert(T t) throws Exception;
	public boolean delete(K key) throws Exception;
	public boolean update(T t) throws Exception;
	public T select(K key) throws Exception;
	public List<T> selectByCondition(Map<Object,Object>conditionMap) throws Exception;
	public List<T> selectAll() throws Exception;
	public void close() throws Exception;
}