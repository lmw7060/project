package 가계부;

import java.awt.HeadlessException;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class HomeBookControl implements Initializable {
	@FXML
	private TableView<HomeBook> table;

	@FXML
	private Label labuserid;

	@FXML
	private TableColumn<HomeBook, String> colday;

	@FXML
	private TableColumn<HomeBook, String> coluserid;

	@FXML
	private TableColumn<HomeBook, Long> colserialno;

	@FXML
	private TableColumn<HomeBook, Long> colrevenue;

	@FXML
	private TableColumn<HomeBook, String> colsection;

	@FXML
	private TableColumn<HomeBook, String> coltitle;

	@FXML
	private TableColumn<HomeBook, String> colremark;

	@FXML
	private TableColumn<HomeBook, Long> colexpense;

	@FXML
	private ComboBox<String> txtsection;

	@FXML
	private TextField txttitlename;

	@FXML
	private TextField txtexpense;

	@FXML
	private TextField txtrevenue;

	@FXML
	private TextField txtserialno;

	@FXML
	private DatePicker txtday;

	@FXML
	private ComboBox<String> txttitle;

	@FXML
	private TextField txtuserid;

	@FXML
	private TextField txtremark;

	@FXML
	private Button btnregist;

	@FXML
	private Button btndelete;

	@FXML
	private Button btnupdate;

	@FXML
	private Button btnselect;

	@FXML
	private Button btnselect1;

	@FXML
	private Button btnlogout;

	@FXML
	private Button btnsaero;

	@FXML
	private Button btnmodify;

    @FXML
    private Button btnhab;

	@FXML
	void regist(ActionEvent event) {
		try {
			HomeBookDAO dao = new HomeBookDAO();
			HomeBook vo = new HomeBook();
			vo.setDay((txtday.getValue()).format(DateTimeFormatter.BASIC_ISO_DATE));
			vo.setSection(txtsection.getValue());
			vo.setRemark(txtremark.getText());
			vo.setRevenue(Long.parseLong(txtrevenue.getText()));
			vo.setExpense(Long.parseLong(txtexpense.getText()));
			vo.setTitleid(dao.actgettitleid(txttitle.getValue()));
			vo.setUserid(txtuserid.getText());
			vo.setTitle(txttitle.getValue());
			// System.out.println(txtday.getValue());
			// System.out.println(vo);
			table.getItems().addAll(vo);
			boolean res = dao.insert(vo);
			if (res) {
				JOptionPane.showMessageDialog(null, vo.getUserid() + "님의 가계부 등록완료");

			}
			dao.close();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (HeadlessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	void delete(ActionEvent event) {
		try {
			HomeBookDAO dao = new HomeBookDAO();
			HomeBook selVo = table.getSelectionModel().getSelectedItem();
			int index = table.getSelectionModel().getSelectedIndex();
			Long key = selVo.getSerialno();
			boolean res = dao.delete(key);
			if (res) {
				JOptionPane.showMessageDialog(null, selVo.getUserid() + "자료삭제");
			}
			table.getItems().remove(index);
			dao.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	void select(ActionEvent event) {
		String titleid = JOptionPane.showInputDialog("찾을계정과목");
		ObservableList<HomeBook> data = table.getItems();
		int num = 0;
		for (int i = 0; i < data.size(); i++) {
			if (data.get(i).getTitleid().equals(titleid)) {
				num = i;
				break;
			}
		}
		//
		table.scrollTo(num);
		table.getSelectionModel().select(num);
	}

	@FXML
	void select1(ActionEvent event) {
		String remark = JOptionPane.showInputDialog("찾을계정과목");
		ObservableList<HomeBook> data = table.getItems();
		int num = 0;
		for (int i = 0; i < data.size(); i++) {
			if (data.get(i).getRemark().equals(remark)) {
				num = i;
				break;
			}
		}
		//
		table.scrollTo(num);
		table.getSelectionModel().select(num);
	}

	@FXML
	void update(ActionEvent event) {
		try {
			int index = table.getSelectionModel().getSelectedIndex();
			HomeBookDAO dao = new HomeBookDAO();
			HomeBook vo = new HomeBook();
			vo.setDay((txtday.getValue()).format(DateTimeFormatter.BASIC_ISO_DATE));
			vo.setUserid(txtuserid.getText());
			vo.setTitleid(txttitle.getValue());
			vo.setSection(txtsection.getValue());
			vo.setRevenue(Long.parseLong(txtrevenue.getText()));
			vo.setExpense(Long.parseLong(txtexpense.getText()));
			vo.setRemark(txtremark.getText());
			vo.setSerialno(Long.parseLong(txtserialno.getText()));
			if (dao.update(vo)) {
				table.getItems().set(index, vo);
				JOptionPane.showMessageDialog(null, "수정완료!");
			}
			dao.close();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			System.out.println("gg");
			e.printStackTrace();
		} catch (HeadlessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	void day(ActionEvent event) {

	}
	// LocalDate.of(2020, 12, 12).format(DateTimeFormatter.BASIC_ISO_DATE);

	@FXML
	void logout(ActionEvent event) {
		int dialogButton = JOptionPane.showConfirmDialog(null, "로그아웃하시겠습니까?", "로그아웃", JOptionPane.YES_NO_OPTION);
		if (dialogButton == JOptionPane.YES_OPTION) {
			Stage stage = (Stage) btnlogout.getScene().getWindow();
			try {
				Parent second = FXMLLoader.load(getClass().getResource("HomeBookLogin.fxml"));
				Scene sc = new Scene(second);
				stage.setScene(sc);
				stage.show();

			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
		}
	}

	@FXML
	void saero(ActionEvent event) {
		JOptionPane.showMessageDialog(null, "새로고침");
		Stage stage = (Stage) btnsaero.getScene().getWindow();
		try {
			Parent second = FXMLLoader.load(getClass().getResource("HomeBook.fxml"));
			Scene sc = new Scene(second);
			stage.setScene(sc);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void modify(ActionEvent event) {
		Stage stage = (Stage) btnmodify.getScene().getWindow();
		try {
			stage = new Stage();
			AnchorPane fourth = FXMLLoader.load(getClass().getResource("HomeBookModi.fxml"));
			Scene sc = new Scene(fourth);
			stage.setScene(sc);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	  @FXML
	    void hab(ActionEvent event) {
		  HomeBookDAO dao = new HomeBookDAO();
		  try {
			  String[] buttons= {"수입","지출"};
			int result = JOptionPane.showOptionDialog(null, "수입/지출을 선택하세요", "수입/지출 합", JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, buttons, "수입");
			  if(result==JOptionPane.CLOSED_OPTION) {
				  JOptionPane.showMessageDialog(null, "수입/지출 합을 찾지않습니다.");
			  }else if (result==JOptionPane.YES_OPTION) {
				  JOptionPane.showMessageDialog(null, dao.hab());
			  }else {
				  JOptionPane.showMessageDialog(null, dao.hab2());
			  }
		} catch (HeadlessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }

	@FXML
	void selectrow(MouseEvent event) {
		HomeBook vo = table.getSelectionModel().getSelectedItem();
		txtserialno.setText(vo.getSerialno() + "");
		txtday.setValue(new Date(System.currentTimeMillis()).toLocalDate());
		txtuserid.setText(vo.getUserid());
		txttitle.setValue(vo.getTitleid());
		txtsection.setValue(vo.getSection());
		txtrevenue.setText(vo.getRevenue() + "");
		txtexpense.setText(vo.getExpense() + "");
		txtremark.setText(vo.getRemark());
	}

	public void setID(String aa) {
		labuserid.setText(aa);
		txtuserid.setText(aa);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		HomeBookDAO dao = new HomeBookDAO();
		ArrayList<String> title_data2 = new ArrayList<String>();
		for (int i = 0; i < dao.title_load().size(); i++) {
			title_data2.add(dao.title_load().get(i).getTitle());
		}
		txttitle.getItems().addAll(title_data2);
		txttitle.setValue(title_data2.get(0));// title combobox
		// --------------------------------------------
		txtsection.getItems().addAll("수입", "지출");// section combobox
		txtsection.setValue("수입");
		// ------------------------------------------------
		txtday.setValue(LocalDate.now());
		try {
			txtserialno.setText(String.valueOf(dao.getMaxSerialno()+1));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//-------------------------------------------------------------------------------------
		colserialno.setCellValueFactory(new PropertyValueFactory<HomeBook, Long>("serialno"));
		colday.setCellValueFactory(new PropertyValueFactory<HomeBook, String>("day"));
		coluserid.setCellValueFactory(new PropertyValueFactory<HomeBook, String>("userid"));
		coltitle.setCellValueFactory(new PropertyValueFactory<HomeBook, String>("titleid"));
		colsection.setCellValueFactory(new PropertyValueFactory<HomeBook, String>("section"));
		colrevenue.setCellValueFactory(new PropertyValueFactory<HomeBook, Long>("revenue"));
		colexpense.setCellValueFactory(new PropertyValueFactory<HomeBook, Long>("expense"));
		colremark.setCellValueFactory(new PropertyValueFactory<HomeBook, String>("remark"));
		try {
			List<HomeBook> data = dao.selectAll();
			table.getItems().addAll(data);
			dao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}