package 가계부;

import java.sql.*;
import java.util.*;


public class AccountTitleDAO implements IDAO<AccountTitle, String> {
	Connection conn = null;
	public AccountTitleDAO() {
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
	}catch(
	ClassNotFoundException e)
	{
		System.err.println("오라클드라이버가 없음!");
		System.exit(0);
	}try
	{
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", // url
				"HOMEBOOK2", // user
				"homebook2"// password
		);
	}catch(
	SQLException e)
	{
		System.err.println("url,user,password점검");
		System.exit(0);
	}
}
	@Override
	public boolean isExists(String key) throws Exception {
		String sql = "select count(*) from AccountTitle where titleid=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, key);
		ResultSet rs =pstmt.executeQuery();
		int cnt =0;
		while(rs.next()) {
			cnt =rs.getInt(1);
		}
		//ResultSetMetaData rsmd = rs.getMetaData();
		conn.close();
		return (cnt>0)?true:false;
	}

	@Override
	public boolean insert(AccountTitle t) throws Exception {
		String sql = "insert into accounttitle (titleid,title)values (?,?)";
		PreparedStatement pstmt =conn.prepareStatement(sql);
		pstmt.setString(1, t.getTitleid());
		pstmt.setString(2, t.getTitle());
		int res = pstmt.executeUpdate();
		conn.close();
		return res>0;
	}

	@Override
	public boolean delete(String key) throws Exception {
		String sql = "delete accounttitle where titleid=?";
		PreparedStatement pstmt =conn.prepareStatement(sql);
		pstmt.setString(1,key);
		int res = pstmt.executeUpdate();
		conn.close();
		return res>0;
	}

	@Override
	public boolean update(AccountTitle t) throws Exception {
		String sql = "update accounttitle set title=? where titleid=?";
		PreparedStatement pstmt =conn.prepareStatement(sql);
		pstmt.setString(1, t.getTitle());
		pstmt.setString(2, t.getTitleid());
		int res = pstmt.executeUpdate();
		conn.close();
		return res>0;
	}

	@Override
	public AccountTitle select(String key) throws Exception {
		String sql = "select * from accounttitle where titleid=?";
		PreparedStatement pstmt =conn.prepareStatement(sql);
		pstmt.setString(1, key);
		ResultSet rs = pstmt.executeQuery();
		AccountTitle vo = new AccountTitle();
		while(rs.next()) {
			//안정성을 위해 컬럼순서를 지양하고 컬럼이용
			vo.setTitleid(rs.getString("TITLEID"));
			vo.setTitle(rs.getString("Title"));
		}
		conn.close();
		return vo;
	}

	@Override
	public List<AccountTitle> selectByCondition(
			Map<Object, Object> conditionMap) throws Exception {
		String sql = "select * from accounttitle where ";
		String sql2= "";//where 절 뒷부분
		for(Object x:conditionMap.keySet()) {
			sql2 = sql2+ (String)x +"="+conditionMap.get((String)x)+" AND ";
		}
		sql2=sql2.substring(0, sql2.length()-5);
		sql = sql+sql2;
		System.out.println(sql);
		PreparedStatement pstmt =conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		List<AccountTitle> list = new ArrayList<>();
		while(rs.next()) {
			AccountTitle vo = new AccountTitle();
			vo.setTitleid(rs.getString("TITLEID"));
			vo.setTitle(rs.getString("TITLE"));
			list.add(vo);
		}
		conn.close();
		return list;
	}

	@Override
	public List<AccountTitle> selectAll() throws Exception {
		String sql = "select * from accounttitle";
		PreparedStatement pstmt =conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		List<AccountTitle> list= new ArrayList<>();
		while(rs.next()) {
			AccountTitle vo = new AccountTitle();
			vo.setTitleid(rs.getString("TITLEID"));
			vo.setTitle(rs.getString("TITLE"));
			list.add(vo);
		}
		conn.close();
		return list;
	}

	@Override
	public void close() throws Exception {
		conn.close();
	}
}
