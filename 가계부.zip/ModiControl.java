package 가계부;


import java.awt.HeadlessException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ModiControl implements Initializable {

    @FXML
    private PasswordField txtpassword;

    @FXML
    private Button btnmodify;

    @FXML
    private Button btnwithdraw;
    
    @FXML
    private Button btncancle;

    @FXML
    private TextField txtuserid;

    @FXML
    private TextField txtusername;

    @FXML
    private TextField txtphone;

    @FXML
    void cancle(ActionEvent event) {
    	
    	Stage stage = (Stage) btncancle.getScene().getWindow();
        try {
           Parent second = FXMLLoader.load(getClass().getResource("HomeBookModi.fxml"));
           Scene sc = new Scene(second);
           stage.setScene(sc);
           stage.close();
        } catch (IOException e) {
           e.printStackTrace();
        }
	    }


    @FXML
    void modify(ActionEvent event) {
    	try {
			Member vo = new Member();
			MemberDAO dao = new MemberDAO();
			vo.setPassword(txtpassword.getText());
			vo.setUsername(txtusername.getText());
			vo.setPhone(txtphone.getText());
			vo.setUserid(txtuserid.getText());
			if(dao.update(vo)) {
				JOptionPane.showMessageDialog(null, "수정완료");
			}
		} catch (HeadlessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    @FXML
    void withdraw(ActionEvent event) {
    try {
		MemberDAO dao=new MemberDAO();
		Member vo = new Member();
		vo.setUserid(txtuserid.getText());
		String key = vo.getUserid();
		boolean res =dao.delete(key);
		if(res) {
			JOptionPane.showMessageDialog(null, vo.getUserid()+"님이 회원탈퇴하셨습니다.");
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    	
    		
    	
    	
    }


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
	}
}
