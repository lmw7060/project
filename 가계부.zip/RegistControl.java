package 가계부;

import java.awt.HeadlessException;
import java.io.IOException;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegistControl {
	String regExphone = "\\d{3}-\\d{3,4}-\\d{4}";

	@FXML
	private TextField txtuserid;

	@FXML
	private PasswordField txtpassword;

	@FXML
	private Button btnregist;

	@FXML
	private Button btnsame;

	@FXML
	private Button btncancle;

	@FXML
	private TextField txtusername;

	@FXML
	private TextField txtphone;

	@FXML
	void regist(ActionEvent event) {
		try {
			if (!Pattern.matches(regExphone, txtphone.getText())) {
				JOptionPane.showMessageDialog(null, "'OOO-OOOO-OOOO'형식으로 기입하세요.");
			} else {
				MemberDAO dao = new MemberDAO();
				Member vo = new Member();
				vo.setUserid(txtuserid.getText());
				vo.setPassword(txtpassword.getText());
				vo.setUsername(txtusername.getText());
				vo.setPhone(txtphone.getText());
				boolean is = dao.isExists(txtuserid.getText());
				if (!is) {
					boolean res = dao.insert(vo);
					JOptionPane.showMessageDialog(null, vo.getUserid() + "님의 가계부 회원가입완료");
					Stage stage = (Stage) btnregist.getScene().getWindow();
					try {
						Parent second = FXMLLoader.load(getClass().getResource("HomeBookLogin.fxml"));
						Scene sc = new Scene(second);
						stage.setScene(sc);
						stage.show();

					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					JOptionPane.showMessageDialog(null, "중복확인을 하세요.");
				}
				dao.close();
			}
		} catch (HeadlessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	void cancle(ActionEvent event) {
		Stage stage = (Stage) btncancle.getScene().getWindow();
		try {
			Parent second = FXMLLoader.load(getClass().getResource("HomeBookLogin.fxml"));
			Scene sc = new Scene(second);
			stage.setScene(sc);
			stage.show();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@FXML
	void same(ActionEvent event) {
			try {
				MemberDAO dao = new MemberDAO();
				boolean is = dao.isExists(txtuserid.getText());
				if (!is) {
					JOptionPane.showMessageDialog(null, "사용가능한 아이디입니다.");
				} else {
					JOptionPane.showMessageDialog(null, "이미존재하는 아이디입니다.");
				}
			} catch (HeadlessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

}