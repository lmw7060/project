package 가계부;

import java.io.IOException;


import javax.swing.JOptionPane;

import 가계부.HomeBookControl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class LoginControl {
	static String x;

    @FXML TextField txtuserid;

    @FXML
    private PasswordField txtpassword;

    @FXML
    private Button btnregist;

    @FXML
    private Button btnlogin;

    @FXML
    void login(ActionEvent event) {
       MemberDAO dao = new MemberDAO();
       x =txtuserid.getText();
       long logininfo = dao.Login(x, txtpassword.getText());
       if (logininfo != 1) {
          JOptionPane.showMessageDialog(null, "로그인실패");
       }
       else{
          JOptionPane.showMessageDialog(null, "로그인성공");  
         loginsuccess(event);  
       }
    }
       private void loginsuccess(ActionEvent event) {
    	try {
    		Stage newStage = new Stage();
    		
    		Stage stage = (Stage) btnlogin.getScene().getWindow();
    		
    		FXMLLoader loader= new FXMLLoader(getClass().getResource("HomeBook.fxml"));
    		
    		AnchorPane second = loader.load();
    		HomeBookControl control = loader.getController();
    		control.setID(txtuserid.getText());
    		
    		Scene sc = new Scene(second);
    		
    		newStage.setScene(sc);
    		newStage.show();
    		stage.close();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    	
    }
	
	@FXML
    void regist(ActionEvent event) {
        Stage stage = (Stage) btnregist.getScene().getWindow();
        try {
           Parent second = FXMLLoader.load(getClass().getResource("HomeBookRegist.fxml"));
           Scene sc = new Scene(second);
           stage.setScene(sc);
           stage.show();

        } catch (IOException e) {
           e.printStackTrace();
        }

     }

    }
  