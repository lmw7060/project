from django.views.generic import ListView, DetailView
from django.views.generic import ArchiveIndexView, YearArchiveView, MonthArchiveView
from django.views.generic import DayArchiveView, TodayArchiveView
from board.models import Board, Comment
from django.shortcuts import redirect
from django.views.generic import CreateView,UpdateView,DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from mysite.views import OwnerOnlyMixin

class BoardLV(ListView):
    model = Board
    template_name = 'board/board_list.html'
    paginate_by = 5

class BoardDV(DetailView):
    model = Board

class BoardAV(ArchiveIndexView):
    model = Board
    date_field = 'modify_dt'


class BoardYAV(YearArchiveView):
    model = Board
    date_field = 'modify_dt'
    make_object_list = True


class BoardMAV(MonthArchiveView):
    model = Board
    date_field = 'modify_dt'


class BoardDAV(DayArchiveView):
    model = Board
    date_field = 'modify_dt'


class BoardTAV(TodayArchiveView):
    model = Board
    date_field = 'modify_dt'
    
def newreply(request):
    if request.method == 'POST':
                comment = Comment()
                comment.comment_content = request.POST['comment_content']
                comment.board = Board.objects.get(pk=request.POST['board']) 
                comment.comment_username = request.user.username
                comment.save()
                return redirect('/board/') 
            
class BoardCreateView(LoginRequiredMixin, CreateView): 
    model = Board 
    fields = ['title', 'slug','content']
    initial = {'slug': 'auto-filling-do-not-input'}
    success_url = reverse_lazy('board:index') 

    def form_valid(self, form): 
        form.instance.owner = self.request.user 
        return super().form_valid(form) 


class BoardChangeLV(LoginRequiredMixin, ListView): 
    template_name = 'board/board_change_list.html' 

    def get_queryset(self):
        return Board.objects.filter(owner=self.request.user)


class BoardUpdateView(OwnerOnlyMixin, UpdateView): 
    model = Board 
    fields = ['title','slug','content'] 
    success_url = reverse_lazy('board:index') 


class BoardDeleteView(OwnerOnlyMixin, DeleteView): 
    model = Board 
    success_url = reverse_lazy('board:index')