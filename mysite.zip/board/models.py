from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User

# dto, database 테이블 설계
class Board(models.Model):
    title = models.CharField(verbose_name='TITLE', max_length=100)
    slug = models.SlugField('SLUG', unique=True, allow_unicode=True, help_text='one word for title alias.',default='')
    content = models.TextField('CONTENT',max_length=300)
    create_dt = models.DateTimeField('CREATE DATE', auto_now_add=True)
    modify_dt = models.DateTimeField('MODIFY DATE', auto_now=True)
    hit = models.IntegerField('HIT',default=0)
    owner = models.ForeignKey(User, on_delete=models.CASCADE,null=True,blank=True)
    
    class Meta:
        verbose_name = 'board'
        verbose_name_plural = 'boards'
        db_table = 'board'
        ordering = ('-modify_dt',)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('board:board_detail', args=(self.slug,))
    
    def get_previous(self):
        return self.get_previous_by_modify_dt()

    def get_next(self):
        return self.get_next_by_modify_dt()

    def update_counter(self):
        self.hit = self.hit +1
        self.save()
        
    
    
class Comment(models.Model):
    board = models.ForeignKey(Board, on_delete=models.CASCADE, null=True, related_name='comments')
    comment_content = models.CharField(max_length=200)
    comment_username = models.CharField(max_length=100,default="")
    comment_user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    
    class Meta:
        ordering = ['-id']