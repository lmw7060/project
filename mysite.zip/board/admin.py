from django.contrib import admin
from board.models import Board,Comment

@admin.register(Board)
class BoardAdmin(admin.ModelAdmin):
    list_display = ('title','content','create_dt','modify_dt','hit')
    list_filter   = ('modify_dt',)
    prepopulated_fields = {'slug': ('title',)} 

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('comment_username','comment_content')