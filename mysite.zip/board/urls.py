from django.urls import path,re_path
from board import views
app_name = 'board'
urlpatterns = [
    path('', views.BoardLV.as_view(), name='index'),
    path('board/', views.BoardLV.as_view(), name='board_list'),
    re_path(r'^board/(?P<slug>[-\w]+)/$', views.BoardDV.as_view(), name='board_detail'),
    path('archive/', views.BoardAV.as_view(), name='board_archive'),
    path('archive/<int:year>/', views.BoardYAV.as_view(), name='board_year_archive'),
    path('archive/<int:year>/<str:month>/', views.BoardMAV.as_view(), name='board_month_archive'),
    path('archive/<int:year>/<str:month>/<int:day>/', views.BoardDAV.as_view(), name='board_day_archive'),
    path('archive/today/', views.BoardTAV.as_view(), name='board_today_archive'),
    path('newreply',views.newreply, name="board_newreply"),
    path('add/',views.BoardCreateView.as_view(), name="add",),
    path('change/',views.BoardChangeLV.as_view(), name="change",),
    path('<int:pk>/update/',views.BoardUpdateView.as_view(), name="update",),
    path('<int:pk>/delete/',views.BoardDeleteView.as_view(), name="delete",),
]

